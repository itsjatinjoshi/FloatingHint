package com.example.floatinghint;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.AutoCompleteTextView;

public class MainActivity extends AppCompatActivity {

    AutoCompleteTextView etFirstName;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        etFirstName= (AutoCompleteTextView) findViewById(R.id.etFirstName);

        String[] names = {"Jatin", "Jack", "Joshi", "John", "Jeniffer", "Justin"};

        ArrayAdapter<String> adapter= new ArrayAdapter<String>(this, R.layout.custom_layout_file, names);

        etFirstName.setThreshold(1);
        etFirstName.setAdapter(adapter);
    }
}
